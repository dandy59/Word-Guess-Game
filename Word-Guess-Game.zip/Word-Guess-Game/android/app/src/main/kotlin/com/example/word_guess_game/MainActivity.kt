package com.example.word_guess_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
